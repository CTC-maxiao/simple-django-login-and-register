import os
import sys
import time
import xml.dom.minidom
import collections

basedir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(basedir,"../base"))
from base_parameter import get_args
from base_cmdmgr import base_cmdmgr
from base_cfgwiz import base_cfgwiz
from base_restapi import base_restapi
from base_linux import run_shell_command
from base_io import backup_file,read_text_file,write_text_file,modify_json_file

class apps_iserver:
    def __init__(self):
        self.mstr_path = get_args("base_paths","mstr_path")
        self.single_saas = get_args("base_paths","single_saas_path")
        self.cluster_saas = get_args("base_paths","cluster_saas_path")        
        self.reg = get_args("apps_iserver","msireg")
        self.status_xml = get_args("apps_iserver","status_xml")

    def test_user_pwd(self,username,password):
        cmdmgr = base_cmdmgr(username,password)
        command = 'LIST ALL PROJECTS;'
        status,output = cmdmgr.run_cmdmgr_command(command)

        if not status:
            if 'name =' not in output:
                return False

        return True

    def pack_user_dict(self,username,password):
        user_dict = {}
        user_dict["username"] = username
        user_dict["password"] = password

        return user_dict

    def get_cfgwiz_object(self,username,password,check_pwd="true"):
        cfgwiz = base_cfgwiz(username,password)
        if check_pwd is "true":
            if self.test_user_pwd(username,password) is False:
                raise UserWarning("password error when create cfgwiz object")

        return cfgwiz

    def get_cmdmgr_object(self,username,password):
        if self.test_user_pwd(username,password) is True:
            cmdmgr = base_cmdmgr(username,password)
            return cmdmgr
        else:
            raise UserWarning("password error when create cmdmgr object")

    def get_restapi_object(self,base_url,svc_user,svc_pwd,tomcat_user,tomcat_pwd):
        if self.test_user_pwd(svc_user,svc_pwd) is True:
            url = "https://" + base_url + "/MicroStrategyLibrary/api/"
            restapi = base_restapi(url,svc_user,svc_pwd,tomcat_user,tomcat_pwd)
            return restapi
        else:
            raise UserWarning("password error when create restful api object")

    def config_iserver(self,cfgwiz,sever_def,md_dsn,md_user,md_pwd,version):
        replaced_params = {}
        replaced_params['+DSNIns+'] = sever_def
        replaced_params['+DSNName+'] = md_dsn
        replaced_params['+DSNUser+'] = md_user
        replaced_params['+DSNPwd+'] = md_pwd
        replaced_params['+SvcUser+'] = cfgwiz.username
        replaced_params['+SvcPwd+'] = cfgwiz.password
        script = """
    [Server]
    Server=1
    Action=2
    InstanceName=""" + replaced_params['+DSNIns+'] + """
    ProjectsToRegister=\\
    ProjectsToUnregister=
    DSName=""" + replaced_params['+DSNName+'] + """
    DSNUser=""" + replaced_params['+DSNUser+'] + """
    DSNPwd=""" + replaced_params['+DSNPwd+'] + """
    MDPrefix=
    DSSUser=""" + replaced_params['+SvcUser+'] + """
    DSSPwd=""" + replaced_params['+SvcPwd+'] + """
    Port=34952
    EncryptPassword=0
    RegisterAsService=0
    StartServerAfterConfig=1
    ConfigureSSL=0
    SSLPort=
    CertificatePath=
    KeyPath=
    KeyPassword=
    DefaultStatisticsRep=0
    DefaultDSNNameDefaultStatistics=
    UserNameDefaultStatistics=
    UserPwdDefaultStatistics=
    EncryptUserPwdDefaultStatistics=
    DefaultStatisticsPrefix=
    DefaultStatisticsBasicStats=
    RESTPort=34962
    RESTAPIPath=api
    """

        new_script = """
    [Server]
    Server=1
    Action=2
    InstanceName=""" + replaced_params['+DSNIns+'] + """
    ProjectsToRegister=\\
    ProjectsToUnregister=
    DSName=""" + replaced_params['+DSNName+'] + """
    DSNUser=""" + replaced_params['+DSNUser+'] + """
    DSNPwd=""" + replaced_params['+DSNPwd+'] + """
    MDPrefix=
    DSSUser=""" + replaced_params['+SvcUser+'] + """
    DSSPwd=""" + replaced_params['+SvcPwd+'] + """
    Port=34952
    EncryptPassword=0
    RegisterAsService=0
    StartServerAfterConfig=1
    ConfigureSSL=0
    SSLPort=
    CertificatePath=
    KeyPath=
    KeyPassword=
    DefaultStatisticsRep=0
    DefaultDSNNameDefaultStatistics=
    UserNameDefaultStatistics=
    UserPwdDefaultStatistics=
    EncryptUserPwdDefaultStatistics=
    DefaultStatisticsPrefix=
    kafkaHost(s)=
    ConfigMessagingService=0
    RESTPort=34962
    RESTAPIPath=api
    """
        if version >= "11.0.0":
            script = new_script

        return cfgwiz.run_cfgwiz(script)

    def create_project_source_win(self,cfgwiz,hostnames,login_mode,custom_id,env_type):
        i = 0
        for hostname in hostnames:
            i = i + 1
            env_type_str =  env_type + "0" + str(i)
            self.create_project_source(cfgwiz,hostname,login_mode,custom_id,env_type_str)

    def create_project_source(self,cfgwiz,hostname,login_mode,custom_id,env_type):
        proj_name = login_mode + " - " + custom_id + " " + env_type + "(" + hostname + ")"
        replaced_params = {}
        replaced_params['+HostName+'] = hostname
        replaced_params['+ProjName+'] = proj_name
        script= """
[Client]
Client=1
EncryptPassword=0
DataSource=""" + replaced_params['+ProjName+'] + """
ConnType=3
DSN=
UserName=
UserPwd=
MDPrefix=
ServerName=""" + replaced_params['+HostName+'] + """
Port=34952
Timeout=5
Authentication=1
"""

        return cfgwiz.run_cfgwiz(script)

    #tested
    def create_cube_folder(self,cluster):
        saas_path = ""
        if cluster == "SINGLENODE":
            saas_path = self.single_saas
        else:
            saas_path = self.cluster_saas

        cube_path = os.path.join(saas_path,"cubes/mstr_cloud")
        cache_path = os.path.join(saas_path,"caches/mstr_cloud")
        inbox_path = os.path.join(saas_path,"inbox/mstr_cloud")

        for _path in [cube_path,cache_path,inbox_path]:
            if not os.path.isdir(_path):
                os.system("sudo mkdir -p " + _path)
            os.system("sudo chown -R mstr:mstr " + _path)
            os.system("chmod -R 775 " + _path)

    #tested
    def update_reg_hostname(self,hostname):
        find_str = False
        new_file = []

        with open(self.reg, 'r') as f:
            for line in f.readlines():
                if '127.0.0.1' in line:
                    line = line.replace('127.0.0.1',hostname)
                    find_str = True
                new_file.append(line)
        if not find_str:
            return

        backup_file(self.reg)

        with open(self.reg, 'w') as f:
            for line in new_file:
                f.write(line)


    #tested
    def update_iserver_pwd(self,cmdmgr,server_user,server_pwd):
        command = 'ALTER USER "' + server_user + '" PASSWORD "' + server_pwd + '";'
        status,output = cmdmgr.run_cmdmgr_command(command)
        
        if status is False:
            raise UserWarning("can't update password for user :" + server_user + ",error message is :" + str(output))

    #tested
    def create_iserver_user(self,cmdmgr,cus_user,cus_pwd):
        command = 'CREATE USER "' + cus_user + '" PASSWORD "' + cus_pwd + '" PASSWORDEXP NEVER ENABLED IN GROUP "System Administrators";'

        status,output = cmdmgr.run_cmdmgr_command(command)  

        is_exist = False
        if status is False:
            for line in output:
                if "cannot create user because its login name is already in use" in line:
                    print "this user is already exist,will update password"
                    is_exist = True
                    self.update_iserver_pwd(cmdmgr,cus_user,cus_pwd)
            if is_exist is False:
                raise UserWarning("can't create user :" + cus_user + ",error message is :" + str(output))
        
    #tested
    def update_cube_path(self,cmdmgr,cluster,project_list=[]):
        failed_list = []
        saas_path = ""
        if cluster == "SINGLENODE":
            saas_path = self.single_saas
        else:
            saas_path = self.cluster_saas
        saas_path = "/" + saas_path

        cube_path = os.path.join(saas_path,"cubes/mstr_cloud").replace("/","\\")
        cache_path = os.path.join(saas_path,"caches/mstr_cloud").replace("/","\\")
        inbox_path = os.path.join(saas_path,"inbox/mstr_cloud").replace("/","\\")

        if not project_list:
            project_list = self.list_all_projects(cmdmgr)

        for proj in project_list:
            command = 'ALTER REPORT CACHING IN PROJECT "' + proj + '" CACHEFILEDIR "' + cache_path + '";'
            cache_status,_ = cmdmgr.run_cmdmgr_command(command)  
            command = 'ALTER PROJECT CONFIGURATION INTELLIGENTCUBEFILEDIR "' + cube_path + '" IN PROJECT "' + proj + '";'
            cube_status,_ = cmdmgr.run_cmdmgr_command(command)  
            if cache_status is False or cube_status is False:
                failed_list.append(proj)

        command = 'ALTER SERVER CONFIGURATION HISTORYDIR "' + inbox_path + '";'
        inbox_status,_ = cmdmgr.run_cmdmgr_command(command) 
        if inbox_status is False:
            failed_list.append("inbox path config")

        return failed_list

    #tested 
    def list_all_projects(self,cmdmgr):
        command = 'LIST ALL PROJECTS;'
        status,output = cmdmgr.run_cmdmgr_command(command)  
        if status is False:
            raise UserWarning("can't list all project,error message is :" + str(output))

        projects = []
        for exe_str in output:
            if 'name =' in exe_str:
                project_name = exe_str.split('= ')[1][:-1]
                projects.append(project_name)

        return projects

    #tested
    def list_loaded_projects(self,cmdmgr):
        command = 'LIST ALL PROJECTS;'
        status,output = cmdmgr.run_cmdmgr_command(command)  
        if status is False:
            raise UserWarning("can't list all loaded project,error message is :" + str(output))

        projects = []
        for exe_str in output:
            if 'name =' in exe_str:
                project_name = exe_str.split('= ')[1][:-1]

            if 'true' in exe_str:
                projects.append(project_name)
        
        return projects

    #tested
    def enable_scheduler(self,cmdmgr):
        _status = self.get_scheduler_state(cmdmgr)
        if _status is True:
            return 

        command = 'ALTER SERVER CONFIGURATION USEMSTRSCHEDULER TRUE;'
        status,output = cmdmgr.run_cmdmgr_command(command)  
        if status is False:
            raise UserWarning("can't enable scheduler,error message is :" + str(output))
    #tested
    def disable_scheduler(self,cmdmgr):
        _status = self.get_scheduler_state(cmdmgr)
        if _status is False:
            return 

        command = 'ALTER SERVER CONFIGURATION USEMSTRSCHEDULER FALSE;'
        status,output = cmdmgr.run_cmdmgr_command(command)
        if status is False:
            raise UserWarning("can't disable scheduler,error message is :" + str(output))
    #tested
    def get_scheduler_state(self,cmdmgr):
        command = 'LIST PROPERTIES FOR SERVER CONFIGURATION;'
        status,output = cmdmgr.run_cmdmgr_command(command)

        if status is False:
            raise UserWarning("can't get scheduler state,error message is :" + str(output))

        scheduler_state = ""
        for exe_str in output:
            if 'use mstr scheduler' in exe_str:
                scheduler_state = exe_str.split('=')[1].replace('\n',"").strip()

        if scheduler_state == "true":
            return True
        elif scheduler_state == "false":
            return False
        else:
            raise UserWarning("can't get scheduler state,error message is :" + str(output))

    def get_hl_type(self,cmdmgr):
        hl_type = ""
        command = 'LIST ALL PROPERTIES FOR SERVER CONFIGURATION;'
        status,output = cmdmgr.run_cmdmgr_command(command)
        if status is False:
            raise UserWarning("can't get history list type,error message is :" + str(output))

        for exe_str in output:
            if 'history list repository type' in exe_str:
                hl_type = exe_str.split('=')[1].replace('\n',"").strip()

        return hl_type   


    def get_ldap_cert(self,cmdmgr):
        cert_file = ""
        file_content = {}
        command = 'LIST PROPERTIES FOR SERVER CONFIGURATION;'
        status,output = cmdmgr.run_cmdmgr_command(command)
        if status is False:
            raise UserWarning("can't get ldap cert location,error message is :" + str(output))

        ldap_type = ""
        for exe_str in output:
            if 'ldap security connection' in exe_str:
                ldap_type = exe_str.split('=')[1].replace('\n',"").strip()

        if "ssl" in ldap_type:
            for exe_str in output:
                if 'ldap server certificate file' in exe_str:
                    cert_path = exe_str.split('=')[1].replace('\n',"").strip()
                    if cert_path != "":
                        cert_file = os.path.join(cert_path,"cacert.pem")

        if os.path.isfile(cert_file):
            file_content = read_text_file(cert_file)

        return file_content

    def write_ldap_cert(self,cert_dict):
        for file_path,file_content in cert_dict.items():
            write_text_file(file_path,file_content)

    def get_server_def(self):
        with open(self.reg,'r') as f:
            for line in f.readlines():
                if 'ServerInstanceName' in line:
                    line = line.strip().split('=')[1].strip('"')
                    return line
        raise UserWarning("can't get server definition in " + self.reg)

    def get_md_dsn(self):
        with open(self.reg,'r') as f:
            for line in f.readlines():
                if (line.find('DSN=')>-1):
                    line = line.strip().replace('"Location"="','').replace(';"','').replace('DSN=','')
                    return line
        raise UserWarning("can't get MD DSN in " + self.reg)

    def get_mstr_version(self):
        dom = xml.dom.minidom.parse(self.status_xml)
        root = dom.documentElement
        ver_node = dom.getElementsByTagName('version')
        version = ver_node[0].firstChild.data

        return str(version)

    def get_service_status(self):
        service_dict = collections.OrderedDict()
        command = "service microstrategy status"
        shell_status,service_output,shell_error=run_shell_command(command)
        if shell_status is False:
            raise UserWarning("failed to get service statu :" + self.shell_error)
        status_list=service_output.split("\n")
        #print status_list
        for value in status_list:
            value = value.strip()
            if ">>>" in value or value =="":
                pass
            else:
                key=""
                kafka_list=["kafka service ", "zookeeper service "]
                for key in kafka_list:
                    if key in value.lower():
                        break
                        #print key
                    else:
                        key=value.split(" is ")[0]
                if "stopped" in value:
                    service_dict[key]="stopped"
                else:
                    service_dict[key]="running"
        return service_dict


    def start_iserver_service(self):
        command = "service mstr iserverstart"
        run_shell_command(command)
        
        self.wait_iserver_start()

    def wait_iserver_start(self):
        count = 0
        while True:
            print "check I-Server status:",self.get_iserver_status()
            if self.get_iserver_status() == "running":
                return True
            time.sleep(10)
            count += 1
            if count*10 > 3600:
                raise UserWarning("wait iserver start time out")        

    def stop_iserver_service(self):
        command = "service mstr iserverstop"
        run_shell_command(command)
        self.wait_iserver_stop()

    def wait_iserver_stop(self):
        count = 0
        while True:
            print "check I-Server status:",self.get_iserver_status()
            if self.get_iserver_status() == "stopped":
                return True
            time.sleep(10)
            count += 1
            if count*10 > 3600:
                raise UserWarning("wait iserver stop time out")            

    def restart_iserver_service(self):
        self.stop_iserver_service()
        self.start_iserver_service()


    def get_iserver_status(self):
        dom = xml.dom.minidom.parse(self.status_xml)
        root = dom.documentElement
        ver_node = dom.getElementsByTagName('state')
        status = ver_node[0].firstChild.data

        return status

    def update_collaborator_url(self,url):
        new_url = "https://" + url + ":443/MicroStrategyLibrary/api"
        config_json = self.mstr_path + "/install/CollaborationServer/config.json"
        modify_json_file(config_json,"authorizationServerUrl",new_url)


    def guess_iserver_pwd(self,username,*passwds):
        for passwd in passwds:
            if self.test_user_pwd(username,passwd) is True:
                return passwd

        raise UserWarning("not find vaild password for user: " + username)

    def disable_session_recovery(self,restapi,cluster):
        if cluster == "SINGLENODE":
            saas_path = self.single_saas
        else:
            saas_path = self.cluster_saas
        saas_path = "/" + saas_path

        inbox_path = os.path.join(saas_path,"inbox/mstr_cloud").replace("/","\\")

        api_path = "v2/iserver/settings"
        data = {"sessionRecoveryPath":{"value":inbox_path},"enableAutoSessionRecovery":{"value": False}}

        status,msg = restapi.patch(api_path,data)
        if status is True:
            return msg
        else:
            raise UserWarning("can't disable session recovery,error message is : " + msg)

    def create_trust_token(self,restapi):
        #restapi = base_restapi("https://env-183215.trial.cloud.microstrategy.com/MicroStrategyLibrary/api/","administrator","2pOtV6FQ3pFl","mstr","2pOtV6FQ3pFl")
        api_path = "admin/restServerSettings/iServer/trustRelationship"

        data = {"webServerPath":"https://env-183215.trial.cloud.microstrategy.com/MicroStrategyLibrary/admin/webserver"}
        status,msg = restapi.post(api_path,data)
        if status is True:
            return msg
        else:
            raise UserWarning("can't create trust relationship token: " + msg)

    def configure_hl_database(self,cfgwiz,db_type,dsn_name,dsn_user,dsn_pwd):
        replaced_params = {}

        replaced_params['+HLSQL+'] = get_args("apps_iserver","history_list","sql_file",db_type)
        replaced_params['+DSNName+'] = dsn_name
        replaced_params['+DSNUser+'] = dsn_user
        replaced_params['+DSNPwd+'] = dsn_pwd

        script = """
[Repository]
Repository=1
EncryptPassword=0
CreateMDTables=0
CreateHistListTables=1
CreateStatTables=0
MetadataPath=
HistoryListPath=""" + replaced_params['+HLSQL+'] + """
DSNName=
UserName=
UserPwd=
MDPrefix=
DBName=
TBName=
DSNNameHist=""" + replaced_params['+DSNName+'] + """
UserNameHist=""" + replaced_params['+DSNUser+'] + """
UserPwdHist=""" + replaced_params['+DSNPwd+'] + """
HistoryPrefix=
HistoryDBName=
HistoryTBName=
DSNNameStats=
UserNameStats=
UserPwdStats=
StatisticsPrefix=
StatisticsPath=
"""

        return cfgwiz.run_cfgwiz(script)

    def configure_hl_setting(self,cmdmgr,hl_db_type,dsn_name,dsn_user,dsn_pwd,cluster):
        if hl_db_type == "mysql":
            db_type = "MySQL 5.x"
        elif hl_db_type == "postgres":
            db_type = "PostgreSQL"
        else:
            pass

        if cluster == "SINGLENODE":
            saas_path = self.single_saas
        else:
            saas_path = self.cluster_saas
        saas_path = "/" + saas_path

        inbox_path = os.path.join(saas_path,"inbox/mstr_cloud").replace("/","\\")

        login_name = get_args("apps_iserver","history_list","login_name")
        conn_name = get_args("apps_iserver","history_list","conn_name")
        dbi_name = get_args("apps_iserver","history_list","dbi_name")
        
        cmd_list = []
        cmd_list.append('DELETE DBINSTANCE "' + dbi_name + '";')
        cmd_list.append('DELETE DBCONNECTION "' + conn_name + '";')
        cmd_list.append('DELETE DBLOGIN "' + login_name + '";')

        for command in cmd_list:
            cmdmgr.run_cmdmgr_command(command) 

        cmd_list = []
        cmd_list.append('CREATE DBLOGIN "' + login_name + '" LOGIN "' + dsn_user + '" PASSWORD "' + dsn_pwd + '";')
            
        if hl_db_type == "mysql":    
            cmd_list.append('CREATE DBCONNECTION "' + conn_name + '" ODBCDSN "' + dsn_name + '" DEFAULTLOGIN "' + login_name + '" CHARSETENCODING NONUTF8 UNIXCHARSETENCODING NONUTF8 EXECMODE SYNCHRONOUS USEEXTENDEDFETCH FALSE USEPARAMQUERIES TRUE DRIVERMODE MULTIPROCESS IDLETIMEOUT 60 MAXCANCELATTEMPT 60 MAXCONNATTEMPT 60 MAXQUERYEXEC -1 TIMEOUT 36000;')
        else:
            cmd_list.append('CREATE DBCONNECTION "' + conn_name + '" ODBCDSN "' + dsn_name + '" DEFAULTLOGIN "' + login_name + '" CHARSETENCODING NONUTF8 UNIXCHARSETENCODING UTF8 EXECMODE SYNCHRONOUS USEEXTENDEDFETCH FALSE USEPARAMQUERIES TRUE DRIVERMODE MULTIPROCESS IDLETIMEOUT 60 MAXCANCELATTEMPT 60 MAXCONNATTEMPT 60 MAXQUERYEXEC -1 TIMEOUT 36000;')
            
        cmd_list.append('CREATE DBINSTANCE "' + dbi_name + '" DBCONNTYPE "' + db_type + '" DBCONNECTION "' + conn_name + '" DESCRIPTION "history list dbi" HIGHTHREADS 10 MEDIUMTHREADS 5 LOWTHREADS 7;')
        cmd_list.append('ALTER SERVER CONFIGURATION CONTENTSERVERDBINSTANCE "' + dbi_name + '" HISTORYLISTREPOSITORYTYPE DBBASED ENABLEREPORTCACHEBACKUP TRUE HYBRIDCENTRALINBOXFILEPATH "' + inbox_path + '";')

        for command in cmd_list:
            status,output = cmdmgr.run_cmdmgr_command(command) 
            if status is False:
                raise UserWarning("failed to configure history list setting :" + str(output))  

    def disable_ootb_user(self,cmdmgr,*enable_user):
        user_list = []
        command = "LIST LOGIN, ENABLED FOR USERS IN GROUP 'Everyone';"
        status,output = cmdmgr.run_cmdmgr_command(command)
        if status is False:
            raise UserWarning("failed to get users :" + str(output)) 

        for line in output:
            if "login = " in line:
                user_list.append(line.split("=")[1].strip())

        for user in user_list:
            if user in enable_user:
                command = "ALTER USER '" + user + "' ENABLED;"
            else:
                command = "ALTER USER '" + user + "' DISABLED;"
            status,output = cmdmgr.run_cmdmgr_command(command)
            if status is False:
                raise UserWarning("failed disable OOTB user :" + str(output)) 
