import os
import sys
import time
from ruamel import yaml
import collections

basedir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(basedir,"../base"))
from base_parameter import get_args
from base_linux import run_shell_command,stop_service,get_pid

class apps_pa:
    def __init__(self):
        self.msg_server_path = get_args("base_paths","msg_server_path")
        self.pa_path = get_args("base_paths","pa_path")
        self.pa_encryptor = get_args("apps_pa","pa_encryptor")
        self.pa_consumer = get_args("apps_pa","pa_consumer")
        self.pa_config = get_args("apps_pa","pa_config")
        
        self.kafka_path = self.get_kafka_path()
        self.tmp_pa_scp = get_args("apps_pa","tmp_pa_scp")       
        self.sys_pa_scp = get_args("apps_pa","sys_pa_scp")

        self.repo_conf = get_args("apps_pa","repo_conf")
        self.repo_script = get_args("apps_pa","repo_script")

    def check_pa_out(self):
        time.sleep(80)

        command = "ls -tr /opt/mstr/PlatformAnalytics/log/*.out | awk 'END {print}'"
        status,stdout,stderr = run_shell_command(command)
        log_file = os.path.join(self.pa_path,"log",stdout.strip())

        file_list=[]
        with open(log_file,"r") as f:
            for line in f.readlines():
                file_list.append(line)

        return file_list[-5:]

    def get_encry_password(self,password):
        command = "/opt/mstr/MicroStrategy/install/_jre/bin/java -jar " + self.pa_encryptor + " '" + password + "'"
        status,out_encry_pwd,stderr = run_shell_command(command)
        if status is False:
            raise UserWarning("failed get envrypted PA password :" + stderr)

        encrypted_pwd = out_encry_pwd.split('Encrypted password generated:')[1].strip()
        encrypted_pwd = encrypted_pwd.replace('/','\/')
        return encrypted_pwd

    def modify_pa_config(self,user,en_password,db_type):
        with open(self.pa_config,"r") as f:
            pa_dict = yaml.round_trip_load(f)

        if db_type == "postgres":
            pa_dict["paEtlConfig"]["pgWarehouseDbConnection"]["pgWhUser"] = user
            pa_dict["paEtlConfig"]["pgWarehouseDbConnection"]["pgWhPasswd"] = en_password
        elif db_type == "mysql":
            pa_dict["paEtlConfig"]["warehouseDbConnection"]["whUser"] = user
            pa_dict["paEtlConfig"]["warehouseDbConnection"]["whPasswd"] = en_password    
        else:
            raise UserWarning("unsupported PA database type :" + db_type)

        with open(self.pa_config,"w") as f:
            yaml.dump(pa_dict,f,Dumper=yaml.RoundTripDumper)

    def modify_dbaadmin_config(self,user,en_password,db_type):
        with open(self.repo_conf,"r") as f:
            repo_dict = yaml.round_trip_load(f)

        if db_type == "postgres":
            repo_dict["pgUser"] = user
            repo_dict["pgPasswd"] = en_password
        elif db_type == "mysql":
            pass
        else:
            raise UserWarning("unsupported PA database type :" + db_type)

        with open(self.repo_conf,"w") as f:
            yaml.dump(repo_dict,f,Dumper=yaml.RoundTripDumper)  

    def get_kafka_path(self):
        for folder in os.listdir(self.msg_server_path):
            full_path = os.path.join(self.msg_server_path,folder)
            if os.path.isdir(full_path):
                if folder.startswith("kafka_"):
                    return full_path

        raise UserWarning("failed to find kafka path")

    def stop_kafka_zookeeper(self):
        stop_kafka_cmd = os.path.join(self.kafka_path,"bin","kafka-server-stop.sh")
        stop_zook_cmd = os.path.join(self.kafka_path,"bin","zookeeper-server-stop.sh")
        run_shell_command(stop_kafka_cmd)
        run_shell_command(stop_zook_cmd)

    def start_zookeeper(self):
        zook_start_cmd = os.path.join(self.kafka_path,"bin","zookeeper-server-start.sh") + " -daemon " + os.path.join(self.kafka_path,"config","zookeeper.properties")
        run_shell_command(zook_start_cmd)

    def start_kafka(self):
        kafka_start_cmd = os.path.join(self.kafka_path,"bin","kafka-server-start.sh") + " -daemon " + os.path.join(self.kafka_path,"config","server.properties")
        run_shell_command(kafka_start_cmd)

    def restart_pa_service(self):
        command = self.pa_consumer + " restart"
        run_shell_command(command)

    def restart_dbaadmin_service(self):
        command = self.repo_script + " restart"
        run_shell_command(command)

    def run_custom_install_script(self):
        custom_install_cmd = "echo 'Y' | sh " + os.path.join(self.pa_path,"bin","platform-analytics-custom-install.sh") + " -o install"
        custom_install_log_check="tail -1 " + os.path.join(self.pa_path,"log","platform-analytics-installation.log") + "| grep -i -c 'Installation finished successfully'"
        out_run_custom_install = self.run_shell_command(custom_install_cmd)
        out_custom_install_log_check = self.run_shell_command(custom_install_log_check)
        print(out_run_custom_install,out_custom_install_log_check)
        if out_run_custom_install[1] == 0 and out_custom_install_log_check[0] == '1':
            return True,'Success'
        else:
            return False,'Fail'

    def create_pa_script(self,load_project,ip,node_type):
        script_path = self.tmp_pa_scp
        sys_pa = []


        with open(script_path,"w") as f:
            f.write("//" + node_type + "\n")
            f.write("""ALTER SERVER CONFIGURATION ENABLEMESSAGINGSERVICES TRUE CONFIGUREMESSAGINGSERVICES "bootstrap.servers:""" + ip + """:9092/batch.num.messages:5000/queue.buffering.max.ms:2000";""" + "\n")
            for line in load_project:
                if line not in ["platform analytics"]:
                    f.write("ALTER PASTATISTICS BASICSTATS ENABLED IN PROJECT "+'"'+line+'";'+"\n")

            if node_type == "OTHERNODE":
                f.write("""CREATE EVENT "Load Object Event";"""+"\n")
                f.write("""CREATE SCHEDULE "Load Object Schedule" STARTDATE 09/10/2010 ENDDATE NEVER TYPE EVENTTRIGGERED EVENTNAME "Load Object Event";"""+"\n")
                f.write("""CREATE MAINTENANCE TASK LOADOBJECTTELEMETRY SCHEDULE "Load Object Schedule";"""+"\n")
                f.write("""TRIGGER EVENT "Load Object Event";"""+"\n")

            for line in sys_pa:
                f.write(line + "\n")

        return script_path

    def create_post_pa_script(self):
        script_path = self.sys_pa_scp
        with open(self.sys_pa_scp,"r") as f:
            sys_pa = f.readlines()

        with open(script_path,"w") as f:
            for line in sys_pa:
                f.write(line + "\n")

        return script_path

    def modify_pa_login(self,cmdmgr,user,password):
        command = 'ALTER DBLOGIN "Platform Analytics PG Login" LOGIN "' + user + '" PASSWORD "' + password + '";'
        status,output = cmdmgr.run_cmdmgr_command(command)
        
        if status is False:
            raise UserWarning("can't update login for Platform Analytics PG Login,error message is :" + str(output))

    def run_pa_script(self,cmdmgr,pa_scp):
        status,output = cmdmgr.run_cmdmgr(pa_scp)
        if status is False:
            raise UserWarning("can't run config PA script:" + pa_scp + ",error message is :" + str(output))