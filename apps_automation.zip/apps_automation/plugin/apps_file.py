import os
import sys

basedir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(basedir,"../base"))
from base_io import read_json_file

class apps_file:
    def __init__(self):
        pass    

    def load_json_file(self,json_path):
        file_content = read_json_file(json_path)
        return file_content