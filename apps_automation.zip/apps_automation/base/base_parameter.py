import os
import yaml
import collections
from base_linux import get_os_type

basedir = os.path.abspath(os.path.dirname(__file__))
CONF_PATH = os.path.join(basedir,"../conf")

if get_os_type() == "linux":
    param_yaml = os.path.join(CONF_PATH,"parameter.yaml")
elif get_os_type() == "windows":
    param_yaml = os.path.join(CONF_PATH,"parameter_windows.yaml")
else:
    raise UserWarning("not support local os type") 

def get_args(*keys):
    if os.path.isfile(param_yaml):
        with open(param_yaml,"r") as f:
            file_content = yaml.load(f,Loader=yaml.Loader)

        if file_content:
            param_value = file_content
            for key in keys:
                if param_value.has_key(key):
                    param_value = param_value[key]
                else:
                    raise UserWarning("parameter file not have this key: " + key)

            return convert_vars(param_value)
        else:
            raise UserWarning("yaml file format error: " + param_yaml)

    else:
        raise UserWarning("yaml file not existed: " + param_yaml) 


def get_full_path(value):
    full_path = ""
    path_dict = collections.OrderedDict()
    for _str in value.split(","):
        if _str.startswith("$"):
            path_dict[_str.strip()] = get_args(*(_str[1:].split(".")))    
        else:
            path_dict[_str.strip()] = _str.strip()

    for _str in path_dict.values():
        full_path = os.path.join(full_path,_str) 

    return full_path

def convert_str_var(value):
    new_value = value
    if value.startswith("join(") and value.endswith(")"):
        value = value[5:-1]    
        new_value = get_full_path(value)

    return new_value

def convert_vars(value):
    if isinstance(value, dict):
        value = convert_task_var_dict(value)
    elif isinstance(value, (list, tuple)):
        value = convert_task_var_list(value)
    else:
        if type(value) == type("type"):
            value = convert_str_var(value)

    return value    


def convert_task_var_dict(dic):
    for key,value in dic.items():
        if isinstance(value, dict):
            dic[key] = convert_task_var_dict(value)
        elif isinstance(value, (list, tuple)):
            dic[key] = convert_task_var_list(value)
        else:
            if type(value) == type("type"):
                dic[key] = convert_str_var(value)

    return dic
        

def convert_task_var_list(value):
    for i,var_ in enumerate(value):
        if isinstance(var_, dict):
            value[i] = convert_task_var_dict(var_)
        elif isinstance(var_, (list, tuple)):
            value[i] = convert_task_var_list(var_)
        else:
            if type(var_) == type("type"):
                value[i] = convert_str_var(var_)

    return value
