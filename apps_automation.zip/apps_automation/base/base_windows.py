import os
import time
import xml.dom.minidom

from base_parameter import get_args
from base_cmdmgr import base_cmdmgr
from base_cfgwiz import base_cfgwiz

class apps_windows:
    def __init__(self):
        pass

    def run_powershell_command(self):
        pass
        