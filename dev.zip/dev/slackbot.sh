#!/bin/bash
bot='slackbot'
script_folder="bin"
script_list=("msg_listener.py" "msg_sender.py" "task_master.py" "cps_monitor.py")

slackbot_start(){
    for key in ${script_list[@]}
    do
        PID=$(ps aux | grep $key | grep python | awk 'NR==1{print $2}')
        if [ -z "$PID" ]; then
            echo "$key is in starting status"
            nohup python3 $script_folder/$key >/dev/null 2>&1 &
        else
            echo "$key is already in running status with PID $PID"
        fi
    done
}

slackbot_stop(){
    for key in ${script_list[@]}
    do
        PID=$(ps aux | grep $key | grep python | awk 'NR==1{print $2}')
        if [ -z "$PID" ]; then
            echo "$key is already in stopped status"
        else
            echo "$key is in stopping status"
        	kill -9 $PID
        fi
    done
}

slackbot_status(){
    for key in ${script_list[@]}
    do
        PID=$(ps aux | grep $key | grep python | awk 'NR==1{print $2}')
        if [ -z "$PID" ]; then
            echo "$key is in stopped status"
        else
            echo "$key is in running status with PID $PID"
        fi
    done
}

slackbot_restart(){
    slackbot_stop
    sleep 5
    slackbot_start
    slackbot_status
}

bot_main(){
    if [ $# != 1 ]; then
        echo "Usage: ${bot}.sh start|stop|restart|status"
    elif [ $1 == "stop" ]; then
        slackbot_stop
    elif [ $1 == "start" ]; then
        slackbot_start
    elif [ $1 == "restart" ]; then
        slackbot_restart
    elif [ $1 == "status" ]; then
        slackbot_status  
    else
        echo "Usage: ${bot}.sh start|stop|restart|status"
    fi
}

bot_main $1
