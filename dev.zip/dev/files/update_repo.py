import os
import json
import hashlib
import zipfile
try:
    PY_VER = "3"
    import urllib.request
    import urllib.parse
except:
    PY_VER = "2"
    import urllib

WORK_PATH = "/opt/mstr"
LOCAL_PATH = "/opt/mstr/apps_automation"
TMP_REPO_FILE = "/tmp/apps_automation.zip"
MD5_JSON = "/opt/mstr/repo_md5.json"

def download_url_file(url,local_file):
    if PY_VER == "2":
        urllib.urlretrieve(url,local_file)
    else:
        urllib.request.urlretrieve(url,local_file)

def get_repo_md5():
    url = 'http://c000ljsp01euw1:5000/get_repo_md5'
    download_url_file(url,MD5_JSON)
    with open(MD5_JSON,"r") as f:
        repo_dict = json.load(f)
    return repo_dict

def download_file(file_name):
    url = 'http://c000ljsp01euw1:5000/download' + '?name=' + file_name
    
    full_path = os.path.join(LOCAL_PATH,file_name)
    folder_path = os.path.dirname(full_path)
    if not os.path.isdir(folder_path):
        os.makedirs(folder_path)
    download_url_file(url,full_path)

def clone_repo():
    if os.path.exists(LOCAL_PATH):
        os.remove(LOCAL_PATH)
    url = 'http://c000ljsp01euw1:5000/clone_repo'
    download_url_file(url,TMP_REPO_FILE)
    t = zipfile.ZipFile(TMP_REPO_FILE)
    t.extractall(path = WORK_PATH)    

def get_file_md5(check_file):
    with open(check_file, 'rb') as fp:
        data = fp.read()
    file_md5= hashlib.md5(data).hexdigest()
    
    return file_md5

def get_local_md5(repo_dict):
    local_dict = {}
    for key,value in repo_dict.items():
        if os.path.isfile(os.path.join(LOCAL_PATH,key)):
            local_dict[key] = get_file_md5(os.path.join(LOCAL_PATH,key))
        else:
            local_dict[key] = ""

    return local_dict

def update_local_repo():
    if not os.path.isdir(LOCAL_PATH):
        clone_repo()
    else:
        repo_md5_dict = get_repo_md5()
        local_md5_dict = get_local_md5(repo_md5_dict)
        for key,value in repo_md5_dict.items():
            if local_md5_dict[key] != value:
                download_file(key)

def main():
    update_local_repo()

main()

