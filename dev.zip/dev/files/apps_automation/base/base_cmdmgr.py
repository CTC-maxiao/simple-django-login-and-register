import os

from base_parameter import get_args
from base_linux import run_shell_command

class base_cmdmgr:
    def __init__(self, user_name, user_pwd):
        self.user_name = user_name
        self.user_pwd = user_pwd
        self.tmp_path = get_args("base_paths","tmp_path")
        self.server_name = get_args("base_cmdmgr","proj_source")
        self.scp_file = get_args("base_cmdmgr","exec_file")
        self.output_file = get_args("base_cmdmgr","output_file")
        self.success = get_args("base_cmdmgr","succ_sign")
        self.cmd_mgr = get_args("base_cmdmgr","cmdmgr")

    def run_cmdmgr(self,scp_path):
        with open(self.output_file,"w") as f:
            f.write("\n")  

        command = self.cmd_mgr + " -n '" + self.server_name + "' -u '" + self.user_name + "'"
        if len(self.user_pwd) > 0:
            command += " -p '" + self.user_pwd + "'"

        command += " -f " + scp_path + " -o " + self.output_file + " -showoutput"

        run_shell_command(command)

        output = []
        with open(self.output_file, 'r') as f:
            for line in f:
                output.append(line.lower())

        found = str(output).find(self.success)
        success = found > -1

        return success, output

    def run_cmdmgr_command(self, script):
        with open(self.scp_file, 'w') as f:
            f.write(script)

        return self.run_cmdmgr(self.scp_file)


