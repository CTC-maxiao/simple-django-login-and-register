import os
import subprocess

from base_parameter import get_args
from base_linux import run_shell_command

class base_cfgwiz:
    def __init__(self,username="",password=""):
        self.username = username
        self.password = password
        self.tmp_path = get_args("base_paths","tmp_path")
        self.tmp_ini = get_args("base_cfgwiz","exec_file")
        self.cfgwiz = get_args("base_cfgwiz","cfgwiz")

  
    def format_projects(self, projects):
        ret_str = ""
        for proj in projects:
            ret_str = ret_str + "{" + proj + "},"

        if ret_str[-1] == ",":
            ret_str = ret_str[:-1]

        return ret_str

    def run_cfgwiz(self, script):
        with open(self.tmp_ini, 'w') as f:
            for line in script:
                f.write(line)

        command = '"' + self.cfgwiz + '"' + " -response " + '"' + self.tmp_ini + '"'

        status,stdout,stderr = run_shell_command(command)

        if status is False:
            raise UserWarning("failed to run cfgwiz file: " + stderr) 

        return status,stdout,stderr
