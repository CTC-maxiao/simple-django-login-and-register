import os
import sys
import subprocess

def run_shell_command(command):
    p = subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
    _stdout,_stderr = p.communicate()
    status = p.wait()

    if status == 0:
        status = True
    else:
        status = False

    return status,_stdout,_stderr

def get_pid(pname):
    _,pids,_ = run_shell_command("pgrep -f " + pname)
    _,pids2,_ = run_shell_command("pgrep -f " + pname)
    pids = pids.split("\n")
    pids2 = pids2.split("\n")
    pid_list = [pid for pid in pids if pid in pids2]

    return pid_list

def get_os_type():
    if sys.platform.startswith('linux'):
        return "linux"
    elif sys.platform.startswith('win32'):
        return "windows"
    else:
        return "other"

def stop_service(command,key_str,timeout=10):
    status,stdout,stderr = run_shell_command(command)

    pid_list = get_pid(key_str)
    i = 0
    while pid_list != [""]:
        for _pid in pid_list:
            run_shell_command("sudo kill -9 " + _pid)
        pid_list = get_pid(key_str)
        i = i + 1
        if i > timeout:
            raise UserWarning("can't stop service: " + key_str) 