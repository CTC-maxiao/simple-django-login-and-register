import os
import requests
import base64

class base_restapi:
    def __init__(self,base_url,svc_user,svc_pwd,tomcat_user,tomcat_pwd):
        self.base_url = base_url
        self.svc_user = svc_user
        self.svc_pwd = svc_pwd
        self.tomcat_user = tomcat_user
        self.tomcat_pwd = tomcat_pwd

    def restful_api_login(self):
        data_post = {'username': self.svc_user,
                    'password': self.svc_pwd,
                    'loginMode': 1}
        r = requests.post(self.base_url + 'auth/login', data=data_post ,verify=False)
        if r.ok:
            authToken = r.headers['X-MSTR-AuthToken']
            cookies = dict(r.cookies)
            return authToken, cookies
        else:
            raise UserWarning("failed to get restapi token,error message is : " + r.text) 
            #print("HTTP %i - %s, Message %s" % (r.status_code, r.reason, r.text))

    def get(self,api_path):
        authToken, cookies = self.restful_api_login()
        headers_get = {'X-MSTR-AuthToken': authToken,
                        'Content-Type': 'application/json'#IMPORTANT!
                        }

        r = requests.get(self.base_url + api_path,headers=headers_get,auth=(self.tomcat_user,self.tomcat_pwd),cookies=cookies,verify=False)
        return r.ok,r.text

    def post(self,api_path,data_dict):
        authToken, cookies = self.restful_api_login()
        headers_post = {'X-MSTR-AuthToken': authToken,
                        'Content-Type': 'application/json',
                        'Accept': '*/*'
                        }
        r = requests.post(self.base_url + api_path, json=data_dict,headers=headers_post,auth=(self.tomcat_user,self.tomcat_pwd),cookies=cookies,verify=False)
        return r.ok,r.text

    def patch(self,api_path,data_dict):
        authToken, cookies = self.restful_api_login()
        headers_post = {'X-MSTR-AuthToken': authToken,
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                        }

        r = requests.patch(self.base_url + api_path, json=data_dict,headers=headers_post,auth=(self.tomcat_user,self.tomcat_pwd),cookies=cookies,verify=False)
        return r.ok,r.text

    def delete():
        pass

    def put():
        pass
