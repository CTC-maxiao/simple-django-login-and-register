import os
import time
import json
import yaml
import shutil
import hashlib
import collections

def copy_file(src_path,tar_path):
    try:
        if not os.path.exists(src_path):
            return False,"file not existed"

        if os.path.isfile(src_path):
            shutil.copy(src_path,tar_path)
            tar_path = os.path.join(tar_path,os.path.basename(src_path))
        else:
            tar_path = os.path.join(tar_path,os.path.basename(src_path))
            shutil.copytree(src_path,tar_path)

        return True,tar_path
    except Exception as e:
        return False,e.message

def delete_files(d_file):
    if not os.path.exists(d_file):
        return True,d_file

    if os.path.isfile(d_file):    
        os.remove(d_file)
    else:
        shutil.rmtree(d_file)

    return True,d_file

def backup_file(file_path):
    if not os.path.exists(file_path):
        raise UserWarning("can't backup file :" + file_path + " beacuse file not existed") 

    bak_time = str(time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime()))
    backup_path = file_path + bak_time

    shutil.copy(file_path,backup_path)

def read_text_file(file_path):
    if not os.path.exists(file_path):
        raise UserWarning("can't read file :" + file_path + " beacuse file not existed") 

    file_content = []
    if os.path.isfile(file_path):
        with open(file_path,"r") as f:
            for line in f.readlines():
                line = line.strip()
                if not line.startswith("#") and line != "":
                    file_content.append(line)   

    return file_content    

def write_text_file(file_path,file_content):
    file_list = []
    if file_content is False:
        return

    if type(file_content) == type("type"):
        file_list.append(file_content)
    else:
        file_list = file_content

    with open(file_path,"w") as f:
        for line in file_list:
            f.write(line)
            f.write("\n")

def get_proper_dict(proper_path):
    proper_dict = collections.OrderedDict()

    proper_list = read_text_file(proper_path)

    for line in proper_list:
        key = line.split("=")[0].strip()
        value = line.split("=")[1].strip()
        proper_dict[key] = value

    return proper_dict

def write_proper_dict(proper_path,proper_dict):
    proper_list = []

    for key,value in proper_dict.items():
        proper_list.append(key + "=" + value + "\n")   

    write_text_file(proper_path,proper_list)     


def update_proper_file(proper_path,proper,ignore=[]):
    if not proper_path.endswith(".properties"):
        return 

    final_proper = []
    src_proper = get_proper_dict(proper_path)
    tar_proper = collections.OrderedDict()
    for line in proper:
        key = line.split("=")[0].strip()
        try:
            value = line.split("=")[1].strip()
            tar_proper[key] = value
        except IndexError:   
            tar_proper[key] = ""
    for key,value in tar_proper.items():
        for ignore_str in ignore:
            if ignore_str not in key:
                src_proper[key] = value

    for key,value in src_proper.items():
        final_proper.append(key + "=" + value)

    write_text_file(proper_path,final_proper)

def get_xml_value(file,*keys):
    import xmltodict
    with open(file,"r") as f:
        doc = xmltodict.parse(f.read())
        r_doc = doc
        for key in keys:
            r_doc = r_doc[key]

    return r_doc

def modify_json_file(json_path,key,value):
    with open(json_path,"r") as f:
        json_file = yaml.safe_load(f)

    json_file[key] = value
    with open(json_path,"w") as f:
        json.dump(json_file,f)

def read_json_file(json_path):
    json_dict = ""
    with open(json_path,"r") as f:
        json_dict = yaml.safe_load(f)

    return json_dict

def get_str_md5(src_str):
    m = hashlib.md5()
    m.update(src_str)

    return m.hexdigest() 
