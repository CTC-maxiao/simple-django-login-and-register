import os
SERVERNAME = "mstr_metadata"
S3_SCRIPT_FOLDER = "/home/mstr"
MSTR_INSTALL = "/opt/mstr/MicroStrategy"
TOMCAT_PATH = "/opt/apache/tomcat/latest"
DOWNLOAD_PATH = "/opt/mstr"
SINGLE_SAAS_PATH = "/opt/mstr/saas_data"
CLUSTER_SAAS_PATH = "/efs/saas_data"

WORK_PATH = "/opt/mstr/apps_automation"
CLD_SCRIPT_PATH = "/root/linux_admin_script/cld_monitoring"
JSON_STORE_PATH = "/mstradmin/applications/upgrade_backups/Json_file/"
TMP_FILE_PATH = "/opt/mstr/apps_automation/apps_tmpfiles"
LOG_PATH = "/opt/mstr/apps_automation/apps_logs"

WAIT_ISERVER_TIMEOUT = 3600

TMP_SHELL_SCRIPT = os.path.join(TMP_FILE_PATH,"apps_script.sh")
TMP_CFGWIZ_INI = os.path.join(TMP_FILE_PATH,"apps_cfgwiz.ini")
TMP_LICENSE_INI = os.path.join(TMP_FILE_PATH,"apps_licmgr.ini")
TMP_UPLOAD_SCRIPT = os.path.join(TMP_FILE_PATH,"apps_upload.sh")
TMP_PA_SCRIPT = os.path.join(TMP_FILE_PATH,"apps_pa.scp")

CMDWIZ_LOG = os.path.join(LOG_PATH,"apps_cmdwiz.log")
CFGWIZ_LOG = os.path.join(LOG_PATH,"apps_cfgwiz.log")

MSIREG = os.path.join(MSTR_INSTALL,"MSIReg.reg")
ODBCFILE = os.path.join(MSTR_INSTALL,"odbc.ini")
WEBAPP_PATH = os.path.join(TOMCAT_PATH,"webapps")
CACHE_PATH = os.path.join(TOMCAT_PATH,"cache")

PA_PATH = os.path.join(DOWNLOAD_PATH,"PlatformAnalytics")
KAFKA_PATH = os.path.join(MSTR_INSTALL,"install/MessagingServices/Kafka/kafka_2.12-2.2.0")
