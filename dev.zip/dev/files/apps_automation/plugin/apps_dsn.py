import os
import sys
import subprocess
import collections

sys.path.append("../base")
from base_parameter import get_args
from base_linux import run_shell_command
from base_io import backup_file,read_text_file,write_text_file

class apps_dsn:
    def __init__(self):
        self.mstr_path = get_args("base_paths","mstr_path")
        self.odbc_ini = get_args("apps_dsn","odbc_ini")
        self.todbc_tool = get_args("apps_dsn","todbc_tool")
        self.cert_key = get_args("apps_dsn","cert_key")
        self.replace_str = get_args("apps_dsn","replace_str")
        self.db_type = get_args("apps_dsn","db_type")
        self.odbc_dict = self.read_odbc_ini()

    def read_odbc_ini(self):
        odbc_dict = collections.OrderedDict()
        dsn_dict = collections.OrderedDict()
        dsn_key = ""
        with open(self.odbc_ini,"r") as f:
            for line in f.readlines():
                line = line.strip()
                if line.startswith("#") or line == "":
                    pass
                elif line.startswith("["):
                    if dsn_key == "":
                        dsn_key = line[1:-1]
                    else:
                        odbc_dict[dsn_key] = dsn_dict.copy()
                        dsn_key = line[1:-1]
                        dsn_dict.clear()
                else:
                    try:
                        key = line.split("=")[0]
                        value = line.split("=")[1]
                        dsn_dict[key] = value
                    except:
                        key = line.split("=")[0]
                        dsn_dict[key] = ""

        odbc_dict[dsn_key] = dsn_dict
        return odbc_dict

    def get_dsn_info(self,dsn):
        if dsn in self.odbc_dict.keys():
            return self.odbc_dict[dsn]
        else:
            raise UserWarning("Not find this DSN in odbc.ini: " + dsn) 

    def write_odbc_ini(self):
        with open(self.odbc_ini,"w") as f:
            for key,value in self.odbc_dict.items():
                f.write("[" + key + "]" + "\n")
                for e_key,e_value in value.items():
                    f.write(e_key + "=" + e_value + "\n")
                f.write("\n")

    def get_dsn_token(self):
        cert_dict = {}

        with open(self.odbc_ini,"r") as f:
            for line in f.readlines():
                for key in self.cert_key:
                    if not line.startswith("#"):
                        if key in line:
                            cert = line.strip().split('=')[1]
                            if cert != "" and os.path.isfile(cert):
                                cert_dict[cert] = read_text_file(cert)

        return cert_dict      

    def create_new_dsn(self,src_dsn,dsn_name,dsn_db):
        self.odbc_dict[dsn_name] = self.odbc_dict[src_dsn].copy()
        self.odbc_dict["ODBC Data Sources"][dsn_name] = self.odbc_dict["ODBC Data Sources"][src_dsn]
        for key in self.odbc_dict[dsn_name].keys():
            if key.lower() == "database":
                self.odbc_dict[dsn_name][key] = dsn_db

        self.write_odbc_ini()

        return dsn_name

    def write_dsn_token(self,token_dict):
        for file_path,file_content in token_dict.items():
            write_text_file(file_path,file_content)

    def test_dsn_conn(self):
        test_result = {}
        dsn_list = self.get_dsn_list()
        
        for dsn in dsn_list:
            print "start testing DSN: " ,dsn
            command = ".cn -d " + dsn + " -u test -p test"
            p = subprocess.Popen(self.todbc_tool,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
            error_code = p.communicate(command)[0].split('\n')[6]
            test_result[dsn] = error_code
        return test_result

    def get_dsn_list(self):
        p = subprocess.Popen(self.todbc_tool,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        dsn_list=[]
        for line in p.communicate('.listdsns')[0].split('\n'):
            if line.startswith('#'):
                dsn_list.append(line.split(' (')[0].replace('# ',''))
        return dsn_list


    def replace_conn_str(self,conn_str,ip):
        conn_str = conn_str.replace(ip,'')
        for _var in self.replace_str:
            conn_str = conn_str.replace(_var,"")

        return conn_str

    def compare_dsn_conn(self,source_conn,old_ip,new_ip):
        local_conn = self.test_dsn_conn()
        #skip_dsn = self.get_not_need_migrate_dsn()

        compare_result = {}
        for key in local_conn.keys():
            if source_conn.has_key(key):
                local_conn_str= self.replace_conn_str(local_conn[key],new_ip)
                source_conn_str = self.replace_conn_str(source_conn[key],old_ip)
                if local_conn_str != source_conn_str:
                    compare_result[key] = {}
                    compare_result[key]["source"] = source_conn_str
                    compare_result[key]["local"] = local_conn_str
            else:  
                compare_result[key] = {}
                compare_result[key]["source"] = "source machine not have this DSN"
                compare_result[key]["local"] = local_conn_str

        return compare_result

    def get_rds_type(self,dsn_name):
        if self.odbc_dict["ODBC Data Sources"].has_key(dsn_name):
            for _type in self.db_type:
                if _type in self.odbc_dict["ODBC Data Sources"][dsn_name].lower():
                    return _type

        else:
            raise UserWarning("can't find this DSN in odbc.ini: " + dsn_name) 

        raise UserWarning("can't get RDS type for this DSN: " + dsn_name) 

    def backup_md_databse(self,db_type,dsn,db_user,db_pwd):
        command_1 = "java -cp DBMigrator.jar:lib/* com.microstrategy.db.utils.DBMigrate -d jdbc:mysql://"
        command_2 = "jdbc:" + db_type + "://"
        command_3 = dsn["host"] + ":" + dsn["port"] + "/" + dsn["database"] + " -u " + db_user + " -p " + db_pwd + " -f " + backup_folder
        command =  command_1 + command_2 + command_3
        run_shell_command(command)
