import os
import re
import sys
import yaml
import socket

basedir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(basedir,"../base"))
from base_parameter import get_args

class apps_system:
    def __init__(self):
        self.mstr_path = get_args("base_paths","mstr_path")

    def get_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
        finally:
            s.close()

        return ip

    def shutdown_exec(self):
        raise UserWarning("shutdown this playbook")

    def get_hostname(self):
        return socket.gethostname()

    def get_url(self):
        url = ""
        config_file = os.path.join(self.mstr_path,"install/CollaborationServer/config.json")
        with open(config_file,"r") as f:
            config_dict = yaml.safe_load(f)

        if config_dict.has_key("authorizationServerUrl"):
            url = config_dict["authorizationServerUrl"].replace("https://","").replace(":443","").replace("/MicroStrategyLibrary/api","")

        return url

    def get_cluster_info(self):
        host = self.get_hostname().lower()

        pattern = re.compile(ur'laio[0-9]')
        cluster_pattern = {
        "SINGLENODE": re.compile(ur'laio[a-z]'),
        "MAINNODE": re.compile(ur'laio1'),
        "OTHERNODE": re.compile(ur'laio[2-9]')
        }

        for key,value in cluster_pattern.items():
            if value.search(host) is not None:
                return key

        raise UserWarning("can't get cluster info,please check hostname format")
