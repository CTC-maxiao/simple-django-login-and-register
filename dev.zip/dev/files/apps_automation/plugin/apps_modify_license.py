#! /usr/bin/env python
import os
import traceback
import sys
from parameter import *
import boto3
from botocore.exceptions import ClientError
import subprocess
from subprocess import Popen, PIPE, STDOUT
import logging

ssm = boto3.client('ssm',region_name = region_nm)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logfile = WORK_PATH + 'iserver_activation.log'
# create a file handler
handler = logging.FileHandler(logfile)
handler.setLevel(logging.INFO)

# create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# add the handlers to the logger
logger.addHandler(handler)

class apps_license:
    def __init__(self):
        self.mstr_install = MSTR_INSTALL
        self.tmp_license_file = TMP_LICENSE_INI
        self.tmp_shell_script = TMP_SHELL_SCRIPT
        self.mstr_hist = os.path.join(self.mstr_install,"log/mstr.hist")
        self.licmgr = os.path.join(self.mstr_install,"bin/mstrlicmgr")
        self.hostname = os.uname()[1]
        self.env_tag = env_tag
        self.envTypeDict = [{"name":"prod","type":"1"},{"name":"dev","type":"2"},{"name":"qa","type":"3"},{"name":"sandbox","type":"3"},{"name":"readonly","type":"3"}]

    def run_command(self,cmd):
        try:
            p = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
            output = p.stdout.read().strip()
            return_code = p.poll()
            return output,return_code
        except Exception as err:
            err_msg = str(err)
            print("Error :%s while running command :%s" %(err_msg,cmd))
            logger.error("Error in running cmd :" + str(cmd) + " message : " + err_msg)
            raise


    def activate_license(self,hostname,cloud_type,env_type):
        try:
            activate_str = self.create_activate_rep(hostname,cloud_type,env_type)
            activate_path = self.write_tmp_file(activate_str,self.tmp_license_file)
            command = self.licmgr + ' -activate -f "' + activate_path + '" ' + "-showoutput"
            succ = os.system(command)
            if succ == 0:
                print("Activation completed successfully")
                logger.info("Activation completed successfully")
                return True,succ
            else:
                return False,succ
        except:
            return False,traceback.format_exc().replace("\n"," ")

    def update_local_license(self,license):
        try:
            update_str = self.create_update_rep(license)
            update_path = self.write_tmp_file(update_str,self.tmp_shell_script)
            print("Update path - " + str(update_path))
            os.chmod(update_path, 0775)
            command = self.licmgr + " -console"
            #succ = os.system("expect " + update_path)
            cmd = "expect " + update_path
            out_update_cmd,out_update_return = self.run_command(cmd)
            print(out_update_cmd,out_update_return)
            #print("Succ - " + str(succ))
            if 'History file updated' in out_update_cmd:
                succ = 0
            else:
                succ = 1
            tmp_status,local_license = self.get_current_license()

            if succ == 0:
                if local_license == license:
                    print("Updated local license key - {} ".format(license))
                    logger.info("Updated local license key - " + str(license))
                    return True,succ
                else:
                    return False,"can't update local license"
                    logger.info("can't update local license")
            else:
                return False,succ

        except:
            err_msg = sys.exc_info()[0]
            logger.error("Error in update_local_license:" + str(err_msg))
            return False,traceback.format_exc().replace("\n"," ")

    def get_current_license(self):
        try:
            current_license = ""
            with open(self.mstr_hist,'r') as f:
                for line in f.readlines():
                    if line.startswith("CDKey="):
                        current_license = line.split("=")[1].strip()
            if current_license:
                return True,current_license
            else:
                return False,"not find any license in mstr.hist"
                logger.info("not find any license in mstr.hist")

        except:
            err_msg = sys.exc_info()[0]
            logger.error("Error in update_local_license:" + str(err_msg))
            return False,traceback.format_exc().replace("\n"," ")

    def write_tmp_file(self,tmp_str,tmp_file):
        tmp_path = os.path.join(tmp_file)
        with open(tmp_path,"w") as f:
            f.write(tmp_str)

        return tmp_path

    def create_activate_rep(self,hostname,cloud_type,env_type):
        #SystemUse = 1 to 5 (1-production,2-development,3-testing,4-training,5-other)
        #Licensed User information for MicroStrategy Point of Contact within the company.
        #InstallerIsLicensedUser = true or false,
        #Set it to true if the person installing the software is an employee of the licensed company.
        #If set to true, please leave the [Installer] section blank.
        #Set it to false if somebody is installing on behalf of the licensed company.
        #If set to false, please fill the [Installer] section.
        replaced_params = {}
        replaced_params['+SystemName+'] = hostname
        replaced_params['+SystemLocation+'] = cloud_type
        replaced_params['+SystemUse+'] = env_type

        activate_file = """
[System]
SystemName=""" + replaced_params['+SystemName+'] + """
SystemLocation=""" + replaced_params['+SystemLocation+'] + """
SystemUse=""" + replaced_params['+SystemUse+'] + """

[CPUs]
IntelligenceServerCPUs=0
WebServerCPUs=0
MobileServerCPUs=0

[LicensedCustomer]
UserCompanyName=mstr
UserFirstName=mstr
UserLastName=mstr
UserDepartment=mstr
UserTitle=mstr
UserEmail=rburman@microstrategy.com
UserPhone=mstr
UserStreet=mstr
UserCity=mstr
UserState=mstr
UserPostal=mstr
UserCountry=mstr
InstallerIsLicensedUser=true

[Installer]
InstallerCompanyName=
InstallerFirstName=
InstallerLastName=
InstallerDepartment=
InstallerTitle=
InstallerEmail=
InstallerPhone=
InstallerStreet=
InstallerCity=
InstallerState=
InstallerPostal=
InstallerCountry=
"""

        return activate_file

    def create_update_rep(self,license):
        #SystemUse = 1 to 5 (1-production,2-development,3-testing,4-training,5-other)
        #Licensed User information for MicroStrategy Point of Contact within the company.
        #InstallerIsLicensedUser = true or false,
        #Set it to true if the person installing the software is an employee of the licensed company.
        #If set to true, please leave the [Installer] section blank.
        #Set it to false if somebody is installing on behalf of the licensed company.
        #If set to false, please fill the [Installer] section.
        replaced_params = {}
        replaced_params['+licmgr+'] = self.licmgr + " -console"
        replaced_params['+license+'] = '"' + license + '"'

        update_file = """
#!/bin/expect
set timeout 30
spawn """ + replaced_params['+licmgr+'] + """
expect -re "(.*)(.). Update local License Key(.*)"
set x $expect_out(2,string)
send "$x\n"
expect "Please enter the new license key.:"
send """ + replaced_params['+license+'] + """
send "\n"
interact
"""

        return update_file





if __name__ == '__main__':
 try:
    apps = apps_license()
    for items in apps.envTypeDict:
            if items['name'] == apps.env_tag:
                license_env_type =  items['type']
    if len(sys.argv) != 2:
      print("Provide options - activate,update or current as 1st argument")
      logger.info("Provide options - activate,update or current as 1st argument")
      sys.exit(1)
    if sys.argv[1] == 'current':
        print("Getting the current license key for - {}".format(apps.hostname))
        out_get_current_license = apps.get_current_license()
        print(out_get_current_license)
        logger.info(out_get_current_license)
    if sys.argv[1] == 'activate':
        print("Activating license for {} ".format(apps.hostname))
        out_activate_license = apps.activate_license(apps.hostname,'US',license_env_type)
        print(out_activate_license)
        logger.info(out_activate_license)
    if sys.argv[1] == 'update':
       out_get_current_license = apps.get_current_license()
       curr_license_key = out_get_current_license[1]
       if not out_get_current_license[0] :
             out_update_local_license = apps.update_local_license(CDKey)
             print(out_update_local_license)
             if out_update_local_license[0]:
               out_activate_license = apps.activate_license(apps.hostname,'US',license_env_type)
               print(out_activate_license)
               logger.info(out_activate_license)

       if curr_license_key != CDKey and out_get_current_license[0]:
           print("Deactivating the current license key")
           logger.info("Deactivating the current license key")
           deactivate_cmd = apps.licmgr + ' -deactivate -showoutput'
           print(deactivate_cmd)
           out_deactivate_cmd,out_return_code = apps.run_command(deactivate_cmd)
           print(out_deactivate_cmd,out_return_code)
           if 'reporting deactivation' in out_deactivate_cmd or out_return_code == 0:
               out_update_local_license = apps.update_local_license(CDKey)
               print(out_update_local_license)
               if out_update_local_license[0]:
                  out_activate_license = apps.activate_license(apps.hostname,'US',license_env_type)
                  print(out_activate_license)
                  logger.info(out_activate_license)
           else:
                 print("Failed to deactivate")
                 logger.info("Failed to deactivate")

       else:
               print("Current license key {} is same as new one, please provide a different license key to update" .format(curr_license_key))
               logger.info("Current license key is same as new one, please provide a different license key to update")
 except Exception as err:
   print("Error -  " + str(err))
   logger.error("Error - " + str(err))
