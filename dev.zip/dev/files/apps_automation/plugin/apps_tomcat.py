import os
import sys
import time
import xml.dom.minidom

basedir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(basedir,"../base"))
from base_parameter import get_args
from base_linux import run_shell_command,get_pid,stop_service
from base_io import read_text_file,write_text_file,get_xml_value,copy_file,update_proper_file,write_proper_dict,get_str_md5

class apps_tomcat:
    def __init__(self):
        self.mstr_path = get_args("base_paths","mstr_path")
        self.tomcat_path = get_args("base_paths","tomcat_path")
        self.webapp_path = get_args("base_paths","webapp_path")
        self.war_path = get_args("apps_tomcat","war_path")
        self.default_proper = get_args("apps_tomcat","default_proper")

    def get_tomcat_user(self):
        tomcat_user = {}
        conf_path = os.path.join(self.tomcat_path,"conf/tomcat-users.xml")
        dom = xml.dom.minidom.parse(conf_path)
        root = dom.documentElement
        users = dom.getElementsByTagName("user")
        for user in users:
            if user.getAttribute("username") == "admin":
                tomcat_user["admin"] = user.getAttribute("password")
            elif user.getAttribute("username") == "webadmin":
                tomcat_user["webadmin"] = user.getAttribute("password")
            elif user.getAttribute("username") == "mstr":
                tomcat_user["mstr"] = user.getAttribute("password")
            else:
                pass
        return tomcat_user

    def get_webapp_type(self,webapp_path,webapp):
        try:
            web_xml = os.path.join(webapp_path,webapp,"WEB-INF/web.xml")
            if not os.path.isfile(web_xml):
                return "other"
                
            servlets = get_xml_value(web_xml,"web-app","servlet")
            servlet_class = []
            for servlet in servlets:
                if servlet.has_key("servlet-class"):
                    servlet_class.append(servlet["servlet-class"])
            if "com.microstrategy.webservices.Axis2.MSTRWSJServlet" in servlet_class:
                return "MicroStrategyWS"
            elif "com.microstrategy.consumerweb.servlets.LibraryMainServlet" in servlet_class:
                return "MicroStrategyLibrary"
            elif "com.microstrategy.web.servlets.MobileServlet" in servlet_class:
                return "MicroStrategyMobile"
            elif "com.microstrategy.web.servlets.ResourceFeed" in servlet_class:
                return "MicroStrategy"            
            else:
                return "other"
        except KeyError:
            return "other"

    def get_all_webapp(self):
        webapp_dict = {}
        directory = os.listdir(self.tomcat_path)
        for _dir in directory:
            full_path = os.path.join(self.tomcat_path,_dir)
            if os.path.isdir(full_path) and "webapp" in _dir:
                #full_path = os.path.join(self.tomcat_path,_dir)
                webapp_dict[_dir] = {}
                for webapp in os.listdir(full_path):
                    if os.path.isdir(os.path.join(full_path,webapp)):
                        _type = self.get_webapp_type(full_path,webapp)
                        if _type != "other":
                            webapp_dict[_dir][webapp] = _type
                            
        return webapp_dict

    def get_mstr_webapp(self):
        mstr_webapp = {}

        for webapp in os.listdir(self.webapp_path):
            if os.path.isdir(os.path.join(self.webapp_path,webapp)):
                _type = self.get_webapp_type(self.webapp_path,webapp)
                if _type != "other":
                    mstr_webapp[webapp] = _type
        return mstr_webapp

    def get_webapp_mount(self,mstr_webapp):
        mount_dict = {}

        for line in read_text_file("/etc/fstab"):
            if "tomcat" in line and "webapp" in line:
                mount_list = line.split(" ")
                mount_list = [i for i in mount_list if i != '']
                mount_dict[mount_list[1]] = mount_list[0]

        return mount_dict

    def get_webapp_link(self,mstr_webapp):
        link_dict = {}
        for webapp,webapp_type in mstr_webapp.items():
            _path = os.path.join(self.webapp_path,webapp)
            file_list = []
            for file in os.listdir(_path):
                file_list.append(os.path.join(_path,file))

            if webapp_type == "MicroStrategyLibrary":
                file_list.append(os.path.join(_path,"WEB-INF/classes/config/configOverride.properties"))

            for _file in file_list:
                if os.path.islink(_file):
                    link_dict[_file] = os.readlink(_file)

        return link_dict

    def get_token_webapp(self,mstr_webapp):
        token_list = []

        for webapp in mstr_webapp.keys():
            xml_path = os.path.join(self.webapp_path,webapp,"WEB-INF/xml")
            if os.path.exists(xml_path):
                for _file in os.listdir(xml_path):
                    if _file.endswith(".token") or _file.endswith(".TOKEN"):
                        token_list.append(webapp)    

        return token_list

    def get_webapp_proper(self,mstr_webapp):
        proper_dict = {}

        for webapp,webapp_type in mstr_webapp.items():
            if webapp_type == "MicroStrategyLibrary":
                proper_path = os.path.join(self.webapp_path,webapp,"WEB-INF/classes/config/configOverride.properties")
            elif webapp_type == "MicroStrategyWS":
                proper_path = os.path.join(self.webapp_path,webapp,"projectsources.xml")
            else:
                proper_path = os.path.join(self.webapp_path,webapp,"WEB-INF/xml/sys_defaults.properties")

            if os.path.isfile(proper_path):
                proper_dict[webapp] = read_text_file(proper_path)

        return proper_dict

    def update_tomcat_pwd(self,admin_pwd,webadmin_pwd,mstr_pwd=""):
        conf_path=os.path.join(self.tomcat_path,"conf/tomcat-users.xml")
        dom = xml.dom.minidom.parse(conf_path)
        root = dom.documentElement
        users = dom.getElementsByTagName("user")
        user_list=[]
        for i in range(len(users)):
            user=users[i]
            if user.getAttribute("username")=="admin":
                user.setAttribute("password",admin_pwd)
            elif user.getAttribute("username")=="webadmin":
                user.setAttribute("password",webadmin_pwd)
            elif user.getAttribute("username")=="mstr":
                if mstr_pwd != "":
                    user.setAttribute("password",mstr_pwd)
            else:
                pass
            user_list.append(user.getAttribute("username"))

        parnNode=dom.getElementsByTagName("tomcat-users")[0]
        if "admin" not in user_list:
            new_node=dom.createElement('user')
            new_node.setAttribute("username","admin")
            new_node.setAttribute("password",admin_pwd)
            new_node.setAttribute("roles","admin,manager,cloud")
            parnNode.appendChild(new_node)
        if "webadmin" not in user_list:
            new_node=dom.createElement('user')
            new_node.setAttribute("username","webadmin")
            new_node.setAttribute("password",webadmin_pwd)
            new_node.setAttribute("roles","cloud")
            parnNode.appendChild(new_node)
        if "mstr" not in user_list:
            new_node=dom.createElement('user')
            new_node.setAttribute("username","mstr")
            new_node.setAttribute("password",mstr_pwd)
            new_node.setAttribute("roles","admin,manager,cloud,mstrWebAdmin")
            parnNode.appendChild(new_node)        

        with open(conf_path,'w') as f:
            dom.writexml(f,indent='',addindent='',newl='')

    def encrypt_tomcat_password(self,admin_pwd,webadmin_pwd,mstr_pwd):
        conf_path = os.path.join(self.tomcat_path,"conf/server.xml")
        dom = xml.dom.minidom.parse(conf_path)
        root = dom.documentElement

        if dom.getElementsByTagName("CredentialHandler") == []:
            entrys = dom.getElementsByTagName("Realm")

            for entry in entrys:
                if entry.getAttribute("className")=="org.apache.catalina.realm.UserDatabaseRealm":
                    new_node=dom.createElement('CredentialHandler')
                    new_node.setAttribute("className","org.apache.catalina.realm.MessageDigestCredentialHandler")
                    new_node.setAttribute("algorithm","MD5")
                    entry.appendChild(new_node)    

            with open(conf_path,'w') as f:
                dom.writexml(f,indent='',addindent='',newl='')

        mstr_pwd = get_str_md5(mstr_pwd)
        admin_pwd = get_str_md5(admin_pwd)
        webadmin_pwd = get_str_md5(webadmin_pwd)
        self.update_tomcat_pwd(admin_pwd,webadmin_pwd,mstr_pwd)

    def create_custom_webapp(self,mstr_webapp):
        self.start_tomcat_service()
        for webapp,war_type in mstr_webapp.items():
            if not os.path.isdir(os.path.join(self.webapp_path,webapp)):
                src_path = os.path.join(self.mstr_path,self.war_path[war_type])
                tar_path = os.path.join(self.webapp_path,webapp + ".war")
                copy_file(src_path,tar_path)

        for webapp in mstr_webapp.keys():
            count = 0
            webapp_path = os.path.join(self.webapp_path,webapp)
            while(not os.path.isdir(webapp_path)):
                print "wait delopy webapp: " + webapp
                time.sleep(10)
                count += 1
                if count*10 > 180:
                    raise UserWarning("time out when deploy webapp" + webapp)

    def update_webapp_proper(self,webapp_proper):
        if webapp_proper == "default":
            webapp_proper = self.default_proper
        for webapp,proper in webapp_proper.items():
            webapp_type = self.get_webapp_type(self.webapp_path,webapp)
            if webapp_type == "MicroStrategyLibrary":
                proper_path = os.path.join(self.webapp_path,webapp,"WEB-INF/classes/config/configOverride.properties")
            elif webapp_type == "MicroStrategyWS":
                proper_path = os.path.join(self.webapp_path,webapp,"projectsources.xml")
            else:
                proper_path = os.path.join(self.webapp_path,webapp,"WEB-INF/xml/sys_defaults.properties")                    

            if os.path.isfile(proper_path):
                update_proper_file(proper_path,proper,ignore=["Token"])


    def insert_cloud_role(self,mstr_webapp):
        for webapp in mstr_webapp.keys():
            insert = False
            xml_path = os.path.join(self.webapp_path,webapp,"WEB-INF/web.xml")
            if os.path.isfile(xml_path):
                dom = xml.dom.minidom.parse(xml_path)    
                root = dom.documentElement
                auth_roles = dom.getElementsByTagName("auth-constraint")
                for role in auth_roles:
                    tmp_role_list = []
                
                    if role.getElementsByTagName("role-name"):                            
                        for sub_role in role.getElementsByTagName("role-name"):
                            tmp_role_list.append(sub_role.childNodes[0].data)

                    if "admin" in tmp_role_list and "cloud" not in tmp_role_list:
                        insert = True
                        cloud_role = dom.createElement("role-name")
                        cloud_role.appendChild(dom.createTextNode("cloud"))
                        role.appendChild(cloud_role)

                security_roles = dom.getElementsByTagName("security-role")
                security_role_list = []
                for role in security_roles:
                    tmp_role_list = []
                
                    if role.getElementsByTagName("role-name"):                            
                        for sub_role in role.getElementsByTagName("role-name"):
                            tmp_role_list.append(sub_role.childNodes[0].data)
                    security_role_list.append(tmp_role_list)

                sec_insert = True
                for role_list in security_role_list:
                    if "cloud" in role_list:
                        sec_insert = False
                        break

                if not security_roles:
                    sec_insert = False
                if sec_insert:
                    insert = True
                    cloud_role = dom.createElement("role-name")
                    cloud_role.appendChild(dom.createTextNode("cloud"))
                    sec_role = dom.createElement("security-role")
                    sec_role.appendChild(cloud_role)
                    root.appendChild(sec_role)

                with open(xml_path,'w') as f:
                    dom.writexml(f,indent='',addindent='',newl='')
                if insert:
                    print "insert cloud role for webapp:",webapp
                else:
                    print "cloud role already exist in webapp:",webapp


    def create_sysdefault_url(self,mstr_webapp,hostname,url):
        for webapp,webapp_type in mstr_webapp.items():
            if webapp_type == "MicroStrategy":
                prop_name = "sys_defaults_" + hostname.upper() + ".properties"
                prop_path = os.path.join(self.webapp_path,webapp,"WEB-INF/xml",prop_name)
                file_content = """consumerWebBaseURL=https\://""" + url + "/MicroStrategyLibrary/"
                write_text_file(prop_path,file_content)


    def update_log_path(self,mstr_webapp):
        for webapp in mstr_webapp.keys():
            logger_prop = os.path.join(self.webapp_path,webapp,"WEB-INF/xml/logger.properties")
            if os.path.isfile(logger_prop):
                file_content = read_text_file(logger_prop)
                for line in file_content:
                    if "/opt/apache/tomcat/" in line:
                        key = line.split("=")[0]
                        log = line.split("/log/")[1]
                        line = key + "=" + "/opt/apache/tomcat/latest/webapps/" + webapp + "/WEB-INF/log/" + log
                write_text_file(logger_prop,file_content)


    def stop_tomcat_service(self):
        stop_tomcat_cmd = "sudo service mstr tomcatstop"
        stop_service(stop_tomcat_cmd,"tomcat")

    def start_tomcat_service(self):
        start_tomcat_cmd = "service mstr tomcatstart"
        run_shell_command(start_tomcat_cmd)
        time.sleep(60)

    def restart_tomcat_service(self):
        self.stop_tomcat_service()
        self.start_tomcat_service()

    def get_mstr_pwd(self):
        user_xml = os.path.join(self.tomcat_path,"conf/tomcat-users.xml")
        dom = xml.dom.minidom.parse(user_xml)
        root = dom.documentElement
        users = dom.getElementsByTagName("user")
        for user in users:
            if user.getAttribute("username") == "mstr":
                mstr_pwd = user.getAttribute("password")
        return mstr_pwd
