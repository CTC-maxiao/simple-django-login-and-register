import os
import sys

sys.path.append("../base")
from base_io import read_json_file

class apps_file:
    def __init__(self):
        pass    

    def load_json_file(self,json_path):
        file_content = read_json_file(json_path)
        return file_content