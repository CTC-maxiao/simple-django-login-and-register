import os
import sys
import yaml
import json
import socket

sys.path.append("../base")
from base_parameter import get_args
from base_linux import run_shell_command

class apps_cloud:
    def __init__(self):
        self.mstr_path = get_args("base_paths","mstr_path")
        self.tmp_path = get_args("base_paths","tmp_path")
        self.cld_params_file = get_args("apps_cloud","params_file")
        self.cloud_type = self.get_cloud_type()
        self.params_dict = self.get_cloud_params()
        self.init_cloud()

    def init_cloud(self):
        if self.cloud_type == "AZURE":
            run_shell_command("az login --identity")

    def get_cloud_type(self):
        _,cloud_info,_ = run_shell_command("cat /etc/motd")
        cloud_info = cloud_info.lower()
        if "azure" in cloud_info:
            return "AZURE"
        elif "amazon" in cloud_info:
            return "AWS"
        elif "aws" in cloud_info:
            return "AWS"
        elif "/home/mstr/microstrategy" in cloud_info:
            return "AWS"
        else:
            raise UserWarning("unkown cloud type")

    def get_cloud_params(self):
        tmp_path = os.path.join(self.tmp_path,"params_config.py")
        os.system("sudo cp -f " + self.cld_params_file + " " + tmp_path)
        os.system("sudo chown mstr:mstr " + tmp_path)
        os.system("chmod 755 " + tmp_path)
        params_dict = {}
        with open(tmp_path,"r") as f:
            for line in f.readlines():
                if not line.startswith("#"):
                    if "=" in line:
                        key = line.split("=")[0].strip().lower()
                        value = line.split("=")[1].strip()
                        params_dict[key] = value

        return params_dict

    def get_env_type(self):
        if self.params_dict.has_key("env_tag"):
            env_type = self.params_dict["env_tag"].strip().replace("'","")
        else:
            env_type = self.params_dict["environment"].strip().replace("'","").split("|")[1]

        if env_type == "prod":
            env_type = "prd"

        return env_type 

    def get_cloud_secret(self,hostname,rds_type):
        custom_id = self.params_dict["customer_id"].lower().replace("'","")
        env_type = self.get_env_type()
        env_id = hostname.split("laio")[0]
        env_type_dict = {
        "prd": "yy",
        "dev": "yd",
        "qa": "yq",
        "sandbox": "ysb",
        "test": "yt",
        "readonly": "yr"
        }
        rds_server = "@" + env_id + "-" + rds_type
        azure_custom_user = custom_id + "-" + env_type + "-administrator"
        azure_user_type = {
        "url":           {"p_type":"-apps-kv", "user_name":"dns-url","p_key":""},
        "mstr":          {"p_type":"-apps-kv", "user_name":"mstr","p_key":""},
        "admin":         {"p_type":"-apps-kv", "user_name":"tomcat-admin","p_key":""},
        "webadmin":      {"p_type":"-apps-kv", "user_name":"tomcat-webadmin","p_key":""},
        "svc_user":      {"p_type":"-apps-kv", "user_name":"administrator","p_key":""},
        "cld_svc_acc":   {"p_type":"-kv", "user_name":"cld-svc-acc","p_key":""},
        "cus_user":      {"p_type":"-apps-kv", "user_name":azure_custom_user,"p_key":""},
        "mddbuser":      {"p_type":"-db-kv",   "user_name":env_type_dict[env_type] + custom_id + "mstrmddb","p_key":rds_server},
        "stdbuser":      {"p_type":"-db-kv",   "user_name":env_type_dict[env_type] + custom_id + "mstrstdb","p_key":rds_server},
        "hldbuser":      {"p_type":"-db-kv",   "user_name":env_type_dict[env_type] + custom_id + "mstrhldb","p_key":rds_server},
        "padbuser":      {"p_type":"-db-kv",   "user_name":env_type_dict[env_type] + custom_id + "mstrpadb","p_key":rds_server}
        }

        aws_custom_user = custom_id + "_" + env_type + "_administrator"
        aws_user_type = {
        "url":           {"p_type":"/apps/", "p_key":"/", "user_name":"dns_url"},
        "mstr":          {"p_type":"/apps/", "p_key":"/prov-portal/", "user_name":"mstr"},
        "admin":         {"p_type":"/apps/", "p_key":"/tomcat-user/", "user_name":"admin"},
        "webadmin":      {"p_type":"/apps/", "p_key":"/tomcat-user/", "user_name":"webadmin"},
        "svc_user":      {"p_type":"/apps/", "p_key":"/mstr-user/", "user_name":"administrator"},
        "cld_svc_acc":   {"p_type":"/apps/", "p_key":"mstr-service-account/", "user_name":"cld_svc_acc"},
        "cus_user":      {"p_type":"/apps/", "p_key":"/mstr-user/", "user_name":aws_custom_user},
        "mddbuser":      {"p_type":"/database/", "p_key":"/", "user_name":env_type_dict[env_type] + custom_id + "mstrmddb"},
        "stdbuser":      {"p_type":"/database/", "p_key":"/", "user_name":env_type_dict[env_type] + custom_id + "mstrstdb"},
        "hldbuser":      {"p_type":"/database/", "p_key":"/", "user_name":env_type_dict[env_type] + custom_id + "mstrhldb"},
        "padbuser":      {"p_type":"/database/", "p_key":"/", "user_name":env_type_dict[env_type] + custom_id + "mstrpadb"}
        }

        full_user_dict = {}
        if self.cloud_type == "AWS":
            user_type = aws_user_type.copy()
        else:
            user_type = azure_user_type.copy()

        for key,user_dict in user_type.items():
            if self.cloud_type == "AWS":
                if key in ["cld_svc_acc"]:
                    full_name = user_dict["p_type"] + user_dict["p_key"] + user_dict["user_name"] 
                else:
                    full_name = user_dict["p_type"] + env_id + user_dict["p_key"] + user_dict["user_name"]   
            else:
                if key in ["cld_svc_acc"]:
                    full_name = "https://" + custom_id + user_dict["p_type"] + ".vault.azure.net/secrets/" + user_dict["user_name"] 
                else:
                    full_name = "https://" + env_id + user_dict["p_type"] + ".vault.azure.net/secrets/" + user_dict["user_name"] 
                
            password = self.get_secret_value(full_name)
            if password is None:
                password = "User not exist!"

            if self.cloud_type == "AWS":
                full_user_dict[key] = {"username":user_dict["user_name"],"password":password}
            else:
                username = user_dict["user_name"] + user_dict["p_key"]
                full_user_dict[key] = {"username":username,"password":password}

        return full_user_dict

    def get_secret_value(self,key):
        if self.cloud_type == "AWS":
            command = "/usr/local/bin/aws ssm get-parameter --name " + key + " --with-decryption --region " + self.params_dict["region_nm"] + " --query 'Parameter.Value' --output text"
        else:
            command = "az keyvault secret show --id " + '"' + key + '"' + ' --query "value"'   

        status,stdout,stderr = run_shell_command(command)
        if "An error occurred" in stdout:
            return None
        
        return stdout.strip().replace('"',"")
