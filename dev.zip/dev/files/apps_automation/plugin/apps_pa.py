import os
import sys
import time
from ruamel import yaml
import collections

basedir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(basedir,"../base"))
from base_parameter import get_args
from base_linux import run_shell_command,stop_service,get_pid

class apps_pa:
    def __init__(self):
        self.pa_path = get_args("base_paths","pa_path")
        self.pa_encry = os.path.join(self.pa_path,"lib","platform-analytics-encryptor.jar")
        self.pa_config = os.path.join(self.pa_path,"conf","PAConsumerConfig.yaml")#get_args("apps_pa","pa_config")
        self.msg_path = "/opt/mstr/MicroStrategy/install/MessagingServices/Kafka"
        self.kafka_path = self.get_kafka_path()
        self.tmp_pa_scp = get_args("apps_pa","tmp_pa_scp")
        self.sys_pa_scp = get_args("apps_pa","sys_pa_scp")

        self.repo_conf = "/opt/mstr/MicroStrategy/install/Repository/repository-administration/conf/DBAdminConfig.yaml"

    def check_pa_out(self):
        time.sleep(80)

        command = "ls -tr /opt/mstr/PlatformAnalytics/log/*.out | awk 'END {print}'"
        status,stdout,stderr = run_shell_command(command)
        log_file = os.path.join(self.pa_path,"log",stdout.strip())

        file_list=[]
        with open(log_file,"r") as f:
            for line in f.readlines():
                file_list.append(line)

        return file_list[-5:]

    def get_encry_password(self,password):
        command = "/opt/mstr/MicroStrategy/install/_jre/bin/java -jar " + self.pa_encry + " '" + password + "'"
        status,out_encry_pwd,stderr = run_shell_command(command)
        if status is False:
            raise UserWarning("failed get envrypted PA password :" + stderr)

        encrypted_pwd = out_encry_pwd.split('Encrypted password generated:')[1].strip()
        encrypted_pwd = encrypted_pwd.replace('/','\/')
        return encrypted_pwd

    def modify_pa_config(self,user,password,db_type):
        password = self.get_encry_password(password)

        with open(self.pa_config,"r") as f:
            pa_dict = yaml.round_trip_load(f)

        if db_type == "postgres":
            pa_dict["paEtlConfig"]["pgWarehouseDbConnection"]["pgWhUser"] = user
            pa_dict["paEtlConfig"]["pgWarehouseDbConnection"]["pgWhPasswd"] = password
        elif db_type == "mysql":
            pa_dict["paEtlConfig"]["warehouseDbConnection"]["whUser"] = user
            pa_dict["paEtlConfig"]["warehouseDbConnection"]["whPasswd"] = password    
        else:
            raise UserWarning("unsupported PA database type :" + db_type)

        with open(self.pa_config,"w") as f:
            yaml.dump(pa_dict,f,Dumper=yaml.RoundTripDumper)

    def get_kafka_path(self):
        for folder in os.listdir(self.msg_path):
            full_path = os.path.join(self.msg_path,folder)
            if os.path.isdir(full_path):
                if folder.startswith("kafka_"):
                    return full_path

        raise UserWarning("failed to find kafka path")

    def stop_kafka_zookeeper(self):
        stop_kafka_cmd = os.path.join(self.kafka_path,"bin","kafka-server-stop.sh")
        stop_zook_cmd = os.path.join(self.kafka_path,"bin","zookeeper-server-stop.sh")
        run_shell_command(stop_kafka_cmd)
        run_shell_command(stop_zook_cmd)
        #stop_service(stop_kafka_cmd,"kafka")
        #stop_service(stop_zook_cmd,"zookeeper")

    def start_kafka_zookeeper(self):
        zook_start_cmd = os.path.join(self.kafka_path,"bin","zookeeper-server-start.sh") + " -daemon " + os.path.join(self.kafka_path,"config","zookeeper.properties")
        kafka_start_cmd = os.path.join(self.kafka_path,"bin","kafka-server-start.sh") + " -daemon " + os.path.join(self.kafka_path,"config","server.properties")
        run_shell_command(zook_start_cmd)
        time.sleep(3)
        run_shell_command(kafka_start_cmd)

    def start_zookeeper(self):
        zook_start_cmd = os.path.join(self.kafka_path,"bin","zookeeper-server-start.sh") + " -daemon " + os.path.join(self.kafka_path,"config","zookeeper.properties")
        run_shell_command(zook_start_cmd)

    def start_kafka(self):
        kafka_start_cmd = os.path.join(self.kafka_path,"bin","kafka-server-start.sh") + " -daemon " + os.path.join(self.kafka_path,"config","server.properties")
        run_shell_command(kafka_start_cmd)

    def restart_pa_service(self):
        command = os.path.join(self.pa_path,"bin","platform-analytics-consumer.sh") + " restart"
        run_shell_command(command)

    def check_pa_status(self):
        log_path = os.path.join(self.pa_path,"log")
        logs = os.listdir(log_path)
        logs.sort(key = lambda fn: os.path.getmtime(log_path + "/" + fn),reverse = True)
        for log in logs:
            if log.startswith("platform-analytics-consumer-health-check") and log.endswith(".out"):
                break

        log_file = os.path.join(self.pa_path,"log",log)
        print("read health check file:",log_file)
        sign = False
        while True:
            with open(log_file,"r") as f:
                lines = f.readlines()
                for i,line in enumerate(lines):
                    if "Health Check Summary" in line:
                        sign = True
                        break
                    if sign:
                        break
                    time.sleep(10)

        with open(log_file,"r") as f:
            lines = f.readlines()
            for line in lines[i + 1:]:
                print(line)
                if "PASS" not in line:
                    return False

        return True

    def run_custom_install_script(self):
        custom_install_cmd = "echo 'Y' | sh " + os.path.join(self.pa_path,"bin","platform-analytics-custom-install.sh") + " -o install"
        custom_install_log_check="tail -1 " + os.path.join(self.pa_path,"log","platform-analytics-installation.log") + "| grep -i -c 'Installation finished successfully'"
        out_run_custom_install = self.run_shell_command(custom_install_cmd)
        out_custom_install_log_check = self.run_shell_command(custom_install_log_check)
        print(out_run_custom_install,out_custom_install_log_check)
        if out_run_custom_install[1] == 0 and out_custom_install_log_check[0] == '1':
            return True,'Success'
        else:
            return False,'Fail'

    def create_pa_script(self,load_project,ip,mainnode):
        script_path = self.tmp_pa_scp
        if mainnode == "MAINNODE":
            env_type = "prod node"
        else:
            env_type = "not prod node"

        sys_pa = []
        with open(self.sys_pa_scp,"r") as f:
            sys_pa = f.readlines()

        with open(script_path,"w") as f:
            f.write("//" + env_type + "\n")
            f.write("""ALTER SERVER CONFIGURATION ENABLEMESSAGINGSERVICES TRUE CONFIGUREMESSAGINGSERVICES "bootstrap.servers:""" + ip + """:9092/batch.num.messages:5000/queue.buffering.max.ms:2000";""" + "\n")
            for line in load_project:
                if line not in ["enterprise manager","platform analytics"]:
                    f.write("ALTER PASTATISTICS BASICSTATS ENABLED IN PROJECT "+'"'+line+'";'+"\n")

            if mainnode == "n":
                f.write("""CREATE EVENT "Load Object Event";"""+"\n")
                f.write("""CREATE SCHEDULE "Load Object Schedule" STARTDATE 09/10/2010 ENDDATE NEVER TYPE EVENTTRIGGERED EVENTNAME "Load Object Event";"""+"\n")
                f.write("""CREATE MAINTENANCE TASK LOADOBJECTTELEMETRY SCHEDULE "Load Object Schedule";"""+"\n")
                f.write("""TRIGGER EVENT "Load Object Event";"""+"\n")

            for line in sys_pa:
                f.write(line + "\n")

        return script_path

    def run_pa_script(self,cmdmgr,pa_scp):
        status,output = cmdmgr.run_cmdmgr(pa_scp)
        if status is False:
            raise UserWarning("can't run config PA script:" + pa_scp + ",error message is :" + str(output))
