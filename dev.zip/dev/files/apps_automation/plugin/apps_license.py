import os
try:
    import subprocess32 as subprocess
except:
    import subprocess
import sys

sys.path.append("../base")
from base_parameter import get_args
from base_linux import run_shell_command

class apps_license:
    def __init__(self):
        self.mstr_path = get_args("base_paths","mstr_path")

        self.tmp_license_file = get_args("apps_license","exec_file")
        self.tmp_shell_script = get_args("apps_license","shell_script")

        self.mstr_hist = get_args("apps_license","mstr_hist")
        self.licmgr = get_args("apps_license","licmgr")

    def activate_license(self,hostname,cloud_type,env_type):
        env_type_dict = {
            "prd": "1",
            "dev": "2",
            "qa": "3",
            "sandbox": "4",
            "test": "4",
            "readonly": "5"
            }
        activate_str = self.create_activate_rep(hostname,cloud_type,env_type_dict[env_type])
        activate_path = self.write_tmp_file(activate_str,self.tmp_license_file)
        command = self.licmgr + ' -activate -f "' + activate_path + '" ' + "-showoutput"

        status,_,_ = run_shell_command(command)
        if status is False:
            raise UserWarning("failed to activate license")            


    def update_linux_license(self,license):
        local_license = self.get_current_license()
        if local_license == license:
            return

        update_str = self.create_update_rep(license)
        update_path = self.write_tmp_file(update_str,self.tmp_shell_script)

        #command = self.licmgr + " -console"
        status,_,_ = run_shell_command("expect " + update_path)

        local_license = self.get_current_license()

        if status is True:
            if local_license != license:
                raise UserWarning("can't update local license")
        else:
            raise UserWarning("can't update local license")


    def get_current_license(self):
        current_license = ""
        with open(self.mstr_hist,'r') as f:
            for line in f.readlines():
                if line.startswith("CDKey="):
                    current_license = line.split("=")[1].strip()
        if current_license:
            return current_license
        else:
            raise UserWarning("not find any license in mstr.hist")
     

    def write_tmp_file(self,tmp_str,tmp_file):
        tmp_path = os.path.join(tmp_file)
        with open(tmp_path,"w") as f:
            f.write(tmp_str)

        return tmp_path

    def create_activate_rep(self,hostname,cloud_type,env_type):
        #SystemUse = 1 to 5 (1-production,2-development,3-testing,4-training,5-other)
        #Licensed User information for MicroStrategy Point of Contact within the company.
        #InstallerIsLicensedUser = true or false,   
        #Set it to true if the person installing the software is an employee of the licensed company. 
        #If set to true, please leave the [Installer] section blank.
        #Set it to false if somebody is installing on behalf of the licensed company. 
        #If set to false, please fill the [Installer] section.          
        replaced_params = {}
        replaced_params['+SystemName+'] = hostname
        replaced_params['+SystemLocation+'] = cloud_type
        replaced_params['+SystemUse+'] = env_type

        activate_file = """
[System]
SystemName=""" + replaced_params['+SystemName+'] + """
SystemLocation=""" + replaced_params['+SystemLocation+'] + """
SystemUse=""" + replaced_params['+SystemUse+'] + """

[LicensedCustomer]
UserCompanyName=mstr
UserFirstName=mstr
UserLastName=mstr
UserDepartment=mstr
UserTitle=mstr
UserEmail=maxiao@microstrategy.com
UserPhone=mstr
UserStreet=mstr
UserCity=mstr
UserState=mstr
UserPostal=mstr
UserCountry=mstr
InstallerIsLicensedUser=true

[Installer]
InstallerCompanyName=
InstallerFirstName=
InstallerLastName=
InstallerDepartment=
InstallerTitle=
InstallerEmail=
InstallerPhone=
InstallerStreet=
InstallerCity=
InstallerState=
InstallerPostal=
InstallerCountry=
"""
    
        return activate_file

    def create_update_rep(self,license):
        #SystemUse = 1 to 5 (1-production,2-development,3-testing,4-training,5-other)
        #Licensed User information for MicroStrategy Point of Contact within the company.
        #InstallerIsLicensedUser = true or false,   
        #Set it to true if the person installing the software is an employee of the licensed company. 
        #If set to true, please leave the [Installer] section blank.
        #Set it to false if somebody is installing on behalf of the licensed company. 
        #If set to false, please fill the [Installer] section.          
        replaced_params = {}
        replaced_params['+licmgr+'] = self.licmgr + " -console"
        replaced_params['+license+'] = '"' + license + '"'

        update_file = """
#!/bin/expect
set timeout 30
spawn """ + replaced_params['+licmgr+'] + """
expect -re "(.*)(.). Update local License Key(.*)"
set x $expect_out(2,string)
send "$x\n"
expect "Please enter the new license key.:"
send """ + replaced_params['+license+'] + """
send "\n"
interact
"""
    
        return update_file

    def update_windows_license(self,license):
        local_license = self.get_current_license()
        if local_license == license:
            return

        lic_mgr = '"' + self.licmgr + '"' + " -console"
        p = subprocess.Popen(lic_mgr,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        #p = subprocess.Popen("C:\\Program Files (x86)\\Common Files\\MicroStrategy\\MALicMgr.EXE -console",stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        command = "2\n" + license + "\n"
        try:
            p.communicate(command,timeout=30)
        except subprocess.TimeoutExpired:
            p.kill()
            raise UserWarning("failed to update license")

        local_license = self.get_current_license()

        if local_license != license:
            raise UserWarning("can't update local license")
