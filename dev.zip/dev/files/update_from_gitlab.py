import os
import json
import hashlib

def get_file_md5(check_file):
    with open(check_file, 'rb') as fp:
        data = fp.read()
    file_md5= hashlib.md5(data).hexdigest()

    return file_md5

def get_local_md5():
    local_dict = {}
    basedir = os.path.join(os.path.abspath(os.path.dirname(__file__)),"apps_automation")
    for root,dirs,files in os.walk(basedir):
        for _file in files:
            full_path = os.path.join(root,_file)
            print(full_path)
            if os.path.isfile(full_path):
                local_dict[full_path.replace(basedir+"/","")] = get_file_md5(full_path)

    return local_dict

def main():
    local_dict = get_local_md5()
    print(local_dict)
    with open("repo_md5.json","w") as f:
        json.dump(local_dict,f)

main()
